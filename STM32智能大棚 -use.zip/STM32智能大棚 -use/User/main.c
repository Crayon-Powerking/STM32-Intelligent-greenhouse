#include "stm32f10x.h"   // Device header
#include "Delay.h"
#include "Timer1.h"
#include "LED.h"
#include "KEY.h"
#include "LightSensor.h"
#include "Buzzer.h"
#include "Encoder.h"
#include "OLED.h"
#include "AD.h"
#include "Motor.h"
#include "DHT11.h"

DHT11_Data_TypeDef DHT11_Data;
uint16_t AD0;
uint8_t KeyNum;
unsigned char mode = 0;
unsigned char line = 0;
unsigned int Lux_w = 0, TA_w = 0, RH_w = 0;;

uint8_t start=0;//初始化OLED
int i=0;

uint16_t Lux_ct,TA_ct,RH_ct,speed;
uint16_t time_max = 3;//对异常数据进行过滤筛选

int8_t Lux_max = 50;//最低光照
int8_t TA_max = 28;//最高温度
int8_t RH_max = 20;//最低湿度

int main(void)//----------------------------------------------初始化各模块并加载大棚界面
{
	LED_Init();
	LightSensor_Init();
	Key_Init();
	Encoder_Init();
	AD_Init();
	Timer3_Init();
	Timer4_Init();
	DHT11_GPIO_Config();
	Motor_Init();
	Buzzer_Init();
	OLED_Init();
	while (1)
	{
//-------------------------------------------------------------------------------------OLED显示
		if(start==0){//------------------------------------------初始化界面只执行一次
			start=1;
			OLED_ShowChinese(0,0,"智能大棚");
			OLED_ShowString(80,0,"RTM/TH",OLED_8X16);
			OLED_ShowString(0,20,"Lux:",OLED_8X16);
			OLED_ShowString(0,34,"TA:",OLED_8X16);
			OLED_ShowString(0,48,"RH:",OLED_8X16);
			OLED_ShowString(88,20,"/",OLED_8X16);
			OLED_ShowString(88,34,"/",OLED_8X16);
			OLED_ShowString(88,48,"/",OLED_8X16);
			OLED_ShowNum(96,20,Lux_max,2,OLED_8X16);
			OLED_ShowNum(96,34,TA_max,2,OLED_8X16);
			OLED_ShowNum(96,48,RH_max,2,OLED_8X16);
			OLED_ShowString(116,26,"lx",OLED_6X8);
			OLED_ShowString(116,40,"C",OLED_6X8);
			OLED_ShowString(116,54,"%  ",OLED_6X8);
		}
		AD0 = (AD_GetValue(ADC_Channel_1) * 100) / 4095;//主循环不断获得传感器获得的AD信号
		if(mode == 0&&Read_DHT11(&DHT11_Data) == SUCCESS)
		{
			OLED_ShowNum(72,20,AD0,2,OLED_8X16);
			OLED_ShowNum(72,34,DHT11_Data.temp_int,2,OLED_8X16);
			OLED_ShowNum(72,48,DHT11_Data.humi_int,2,OLED_8X16);
//-------------------------------------------------------------------------------------测试数据位
//			OLED_ShowNum(28,48,RH_ct,4,OLED_8X16);
//			OLED_ShowNum(28,34,TA_ct,4,OLED_8X16);
//			OLED_ShowNum(36,20,Lux_ct,3,OLED_8X16);
//---------------------------------------------------------------------------
			OLED_Update();
		}
//-----------------------------------------------------------------------------------------------------------------------------
		if(mode==1 || mode==0)
		{
			switch(line)//角标显示，提示使用者，当前可以调节的阈值
			{
				case 1:
				{
					OLED_ShowString(64,20,"*",OLED_8X16);
					OLED_ShowString(64,34," ",OLED_8X16);
					OLED_ShowString(64,48," ",OLED_8X16);
					OLED_Update();  
				}break;           
				case 2:           
				{                 
					OLED_ShowString(64,20," ",OLED_8X16);
					OLED_ShowString(64,34,"*",OLED_8X16);
					OLED_ShowString(64,48," ",OLED_8X16);
					OLED_Update();  
				}break;           
				case 3:           
				{                 
					OLED_ShowString(64,20," ",OLED_8X16);
					OLED_ShowString(64,34," ",OLED_8X16);
					OLED_ShowString(64,48,"*",OLED_8X16);
					OLED_Update();  
				}break;		        
				default:          
				{                 
					OLED_ShowString(64,20," ",OLED_8X16);
					OLED_ShowString(64,34," ",OLED_8X16);
					OLED_ShowString(64,48," ",OLED_8X16);
					OLED_Update();
				}break;
			}
			if(line == 1)//旋转编码器实现快速调节阈值
			{
				Lux_max += Encoder_Get();
				if(Lux_max>99)Lux_max = 99;
				if(Lux_max<0)Lux_max = 0;
				OLED_ShowNum(96,20,Lux_max,2,OLED_8X16);
				OLED_Update();
			}
			if(line == 2)
			{
				TA_max += Encoder_Get();
				if(TA_max>50)TA_max = 50;
				if(TA_max<0)TA_max = 0;
				OLED_ShowNum(96,34,TA_max,2,OLED_8X16);
				OLED_Update();
			}
			if(line == 3)
			{
				RH_max += Encoder_Get();
				if(RH_max>99)RH_max = 99;
				if(RH_max<0)RH_max = 0;
				OLED_ShowNum(96,48,RH_max,2,OLED_8X16);
				OLED_Update();
			}	
		}
//--------------------------------------------------------------------------------------------------------------------------		
		KeyNum = Key_GetNum();//获取按键一进入阈值调节模式，同时可以选择温度、湿度、光强三种阈值调节
		if(KeyNum == 1 && (mode==0 || mode == 1))
		{
			mode = 1;
			line++;
			if(line == 4)
			{
				line = 0;
				mode = 0;
			}
		}else if(KeyNum==2){
			if(i==0){
				i=1;
				mode=2;
				OLED_Clear();
				OLED_Update();
			}
			else{
				i=0;
				mode=0;
				start=0;
			}
		}
//--------------------------------------------------------------------------------------------------------------------------
		if(mode == 0)//**_w的作用是防止蜂鸣器重复响起
		{	
			if(Lux_ct>time_max && Lux_w == 0)
			{
				Buzzer_ON();
				Delay_ms(500);
				Buzzer_OFF();
				Lux_w = 1;
			}
			if(TA_ct>time_max && TA_w == 0)
			{
				Buzzer_ON();
				Delay_ms(500);
				Buzzer_OFF();
				TA_w = 1;
			}
			if(RH_ct>time_max && RH_w == 0)
			{
				Buzzer_ON();
				Delay_ms(500);
				Buzzer_OFF();
				RH_w = 1;
			}
		}
	}
}

//--------------------------------------------------------------------------------------------------------------------------
void TIM4_IRQHandler(void)//----------定时器实现计时功能
{
	if (TIM_GetITStatus(TIM4, TIM_IT_Update) == SET)
	{
		if(mode == 0)
		{

			if(AD0>Lux_max){
				if(Lux_ct<=time_max){
				Lux_ct++;//如果光照强度低于阈值开始计时，同时限制计数停止自增，防止超过int值后系统发生未知错乱
				}
			}
			else Lux_ct = 0;//-------------------------------------华丽分割线	
			if(DHT11_Data.temp_int>TA_max){
				if(TA_ct<=time_max){
					TA_ct++;//如果温度高于阈值开始计时
				}	
			}
			else TA_ct = 0;//-------------------------------------华丽分割线			
			if(DHT11_Data.humi_int<RH_max){
				if(RH_ct<=time_max){
					RH_ct++;//如果湿度低于阈值开始计时
				}	
			}
			else RH_ct = 0;
		}
		TIM_ClearITPendingBit(TIM4, TIM_IT_Update);
	}
}
void TIM3_IRQHandler(void)//-----------------------------------------------------定时器实现功能函数
{
	if (TIM_GetITStatus(TIM3, TIM_IT_Update) == SET)
	{
		if(mode==0)
		{
//超过光照强度低于阈值time_max 秒后，自动开启LED补光------------------------------------------
			if(Lux_ct>time_max)
			{
				LED_level(AD0,Lux_max);
			}
			if(AD0<Lux_max)//当高于后自动关闭
			{
				Lux_w = 0;
				Lux_ct = 0;
				LED_ALL_OFF();
			}
		}
//如果温度高于阈值 time_max 秒，自动开启风扇降温---------------------------------------------------------
			if(TA_ct>time_max)
			{
				speed = (DHT11_Data.temp_int - TA_max)*20+10;
				if(speed >= 100)speed = 100;
				Motor_SetSpeed(speed);
			}
			if(DHT11_Data.temp_int < TA_max)//温度低于后自动降速直至关闭
			{
				TA_w = 0;
				TA_ct = 0;
				Motor_SetSpeed(0);
			}
//如果湿度低于阈值 time_max 秒，自动开启水泵补水，高于阈值后，自动关闭-----------------------------------------------				
			if(DHT11_Data.humi_int>RH_max)
			{
				RH_ct = 0;
				RH_w = 0;
			}
		if(mode == 1 || mode == 2)//当进入调节阈值模式时，关闭所有模块同时计数清零
		{
			Lux_ct = 0;
			TA_ct = 0;
			RH_ct = 0;
			LED_ALL_OFF();
			speed = 0;
			Motor_SetSpeed(speed);
		}
		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
	}
}

