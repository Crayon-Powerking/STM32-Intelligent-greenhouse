#ifndef __TIMER1_H
#define __TIMER1_H

void Timer2_Init(void);
void Timer3_Init(void);
void Timer4_Init(void);
void Timer_ALL_Init(void);

#endif
