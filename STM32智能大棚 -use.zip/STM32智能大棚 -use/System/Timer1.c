#include "stm32f10x.h"                  // Device header

void Timer2_Init(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);	//选择APB1总线下的定时器Timer2
	
	TIM_InternalClockConfig(TIM2);		//TIM2使用内部时钟
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_TimeBaseInitStructure.TIM_ClockDivision 	= TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode 		= TIM_CounterMode_Up;//计数模式，此处为向上计数
	TIM_TimeBaseInitStructure.TIM_Period 			= 100-1;	//ARR
	TIM_TimeBaseInitStructure.TIM_Prescaler 		= 7200-1;	//PSC
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;	//高级计时器特有，重复计数
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStructure);
	
	TIM_ClearFlag(TIM2, TIM_FLAG_Update);

	TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);		//使能中断	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;		//中断通道选择
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;		//优先级，同上	
	NVIC_Init(&NVIC_InitStructure);
	
	TIM_Cmd(TIM2, ENABLE);		//打开定时器
}

void Timer3_Init(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);  //开启内部时钟
	
	TIM_InternalClockConfig(TIM3);  //时基单元由内部时钟驱动（默认内部时钟不写也行）
	
	TIM_TimeBaseInitTypeDef TIM_Timebase_initstruct;
	TIM_Timebase_initstruct.TIM_ClockDivision     = TIM_CKD_DIV1;  //时钟分频
	TIM_Timebase_initstruct.TIM_CounterMode       = TIM_CounterMode_Up;  //计数模式
	TIM_Timebase_initstruct.TIM_Period            = 100-1;  //arr自动重装器
	TIM_Timebase_initstruct.TIM_Prescaler         = 7200-1;  //psc预分频器
	TIM_Timebase_initstruct.TIM_RepetitionCounter = 0;  //重复计数器	
	TIM_TimeBaseInit(TIM3,&TIM_Timebase_initstruct);  //初始化时基单元
	
	TIM_ClearFlag(TIM3,TIM_FLAG_Update);  //手动更新中断标志位，以抵消初始自动开启+1情况
	
	TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE);  //开启更新中断到NVIC通道	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);  //配置NVIC
	NVIC_InitTypeDef NVIC_initstruct;
	NVIC_initstruct.NVIC_IRQChannel=TIM3_IRQn;
	NVIC_initstruct.NVIC_IRQChannelCmd=ENABLE;
	NVIC_initstruct.NVIC_IRQChannelPreemptionPriority=2;  //抢占优先级
	NVIC_initstruct.NVIC_IRQChannelSubPriority=1;	  //响应优先级
	NVIC_Init(&NVIC_initstruct);  //初始化NVIC
	
	TIM_Cmd(TIM3,ENABLE);  //开启定时器
}

void Timer4_Init(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4,ENABLE);  //开启内部时钟
	
	TIM_InternalClockConfig(TIM4);  //时基单元由内部时钟驱动（默认内部时钟不写也行）
	
	TIM_TimeBaseInitTypeDef TIM_Timebase_initstruct;
	TIM_Timebase_initstruct.TIM_ClockDivision     = TIM_CKD_DIV1;  //时钟分频
	TIM_Timebase_initstruct.TIM_CounterMode       = TIM_CounterMode_Up;  //计数模式
	TIM_Timebase_initstruct.TIM_Period            = 10000-1;  //arr自动重装器
	TIM_Timebase_initstruct.TIM_Prescaler         = 7200-1;  //psc预分频器
	TIM_Timebase_initstruct.TIM_RepetitionCounter = 0;  //重复计数器	
	TIM_TimeBaseInit(TIM4,&TIM_Timebase_initstruct);  //初始化时基单元
	
	TIM_ClearFlag(TIM4,TIM_FLAG_Update);  //手动更新中断标志位，以抵消初始自动开启+1情况
	
	TIM_ITConfig(TIM4,TIM_IT_Update,ENABLE);  //开启更新中断到NVIC通道	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);  //配置NVIC
	NVIC_InitTypeDef NVIC_initstruct;
	NVIC_initstruct.NVIC_IRQChannel=TIM4_IRQn;
	NVIC_initstruct.NVIC_IRQChannelCmd=ENABLE;
	NVIC_initstruct.NVIC_IRQChannelPreemptionPriority=2;  //抢占优先级
	NVIC_initstruct.NVIC_IRQChannelSubPriority=1;	  //响应优先级
	NVIC_Init(&NVIC_initstruct);  //初始化NVIC
	
	TIM_Cmd(TIM4,ENABLE);  //开启定时器
}

void Timer_ALL_Init(void)
{
	Timer2_Init();
	Timer3_Init();
	Timer4_Init();
}
/* 定时器中断函数，可以复制到使用它的地方
void TIM3_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM3, TIM_IT_Update) == SET)
	{
		
		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
	}
}
*/

