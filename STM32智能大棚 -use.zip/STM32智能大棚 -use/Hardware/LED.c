#include "stm32f10x.h"                  // Device header
#include "OLED.h"

/**
  * 函    数：LED初始化
  * 参    数：无
  * 返 回 值：无
  */
void LED_Init(void)
{
	/*开启时钟*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);		//开启GPIOA的时钟
	
	/*GPIO初始化*/
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11 | GPIO_Pin_10 | GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);						
	
	/*设置GPIO初始化后的默认电平*/
	GPIO_SetBits(GPIOA, GPIO_Pin_11 | GPIO_Pin_10 | GPIO_Pin_9);
}

void LED_ALL_ON(void)
{
	GPIO_ResetBits(GPIOA, GPIO_Pin_11 | GPIO_Pin_10 | GPIO_Pin_9);
}
void LED_ALL_OFF(void)
{
	GPIO_SetBits(GPIOA, GPIO_Pin_11 | GPIO_Pin_10 | GPIO_Pin_9);
}

void LED_level(int level, int Lux_max)
{
    int diff = level - Lux_max; // 计算光照差值（越大代表光越暗）
    if (diff <= 0)
    {
        GPIO_SetBits(GPIOA, GPIO_Pin_11 | GPIO_Pin_10 | GPIO_Pin_9);  // 光照充足，关闭所有 LED
        return;
    }
    // 计算亮度等级（将光照强度分为 4 个等级）
    int step = Lux_max / 4;
    int brightness_level = diff / step; // 计算当前亮度等级
    switch (brightness_level)
    {
        case 3:  // 最暗，全部 LED 亮起
        case 4:  // 由于 `diff/step` 可能大于 3，加入 case 4 兜底
            GPIO_ResetBits(GPIOA, GPIO_Pin_11 | GPIO_Pin_10 | GPIO_Pin_9);
            break;

        case 2:  // 次暗，点亮 2 颗 LED
            GPIO_ResetBits(GPIOA, GPIO_Pin_10 | GPIO_Pin_9);
            GPIO_SetBits(GPIOA, GPIO_Pin_11);
            break;

        case 1:  // 轻微偏暗，点亮 1 颗 LED
            GPIO_ResetBits(GPIOA, GPIO_Pin_10);
            GPIO_SetBits(GPIOA, GPIO_Pin_9 | GPIO_Pin_11);
            break;

        default: // 光照充足，关闭所有 LED
            LED_ALL_OFF();
            break;
    }
}
